fetch('https://pokeapi.co/api/v2/pokemon')
    .then(Response => Response.json())
    .then(data => {
        for (let index = 0; index < data.results.length; index++) { 
            fetch('https://pokeapi.co/api/v2/pokemon/' + data.results[index].name)
                .then(Response => Response.json())
                .then(datos => {
                    let nombres=[];
                    let puntos=[];
                    for(let i=0; i<datos.stats.length;i++){
                        puntos[i]=datos.stats[i].base_stat;
                        nombres[i]=datos.stats[i].stat.name;
                    }
                    document.getElementById('grid').innerHTML +=
                    "<div id='" + data.results[index].name + "'><img id='imagen' src=" + datos.sprites.front_default + "><p>" + data.results[index].name.toUpperCase() + "</p></div>";
                    document.getElementById("select").innerHTML+="<option>"+data.results[index].name.toUpperCase()+"</option>";    
                    for(let z=0; z<puntos.length;z++){
                        document.getElementById(data.results[index].name).innerHTML +="<p>"+nombres[z].toUpperCase()+" : "+puntos[z]+"</p>";
                    }
                });
        }
    });
    
    document.getElementById("select").addEventListener('change',function(){
        if(select.value!=""){
            fetch('https://pokeapi.co/api/v2/pokemon/'+select.value.toLowerCase())
            .then(Response=>Response.json())
            .then(datos=>{
                let nombres=[];
                let puntos=[];
                    for(let i=0; i<datos.stats.length;i++){
                        puntos[i]=datos.stats[i].base_stat;
                        nombres[i]=datos.stats[i].stat.name;
                    }
                    document.getElementById('grid').innerHTML =
                    "<div id='" + select.value + "'><img id='imagen' src=" + datos.sprites.front_default + "><p>" +select.value + "</p></div>";
                    for(let z=0; z<puntos.length;z++){
                        document.getElementById(select.value).innerHTML +="<p>"+nombres[z].toUpperCase()+" : "+puntos[z]+"</p>";
                    }
            });
        }else{
            location.reload();
        }
    }); 